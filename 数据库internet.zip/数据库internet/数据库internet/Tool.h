#pragma once
#include<time.h>
#include<string>
#include"global.h"
using namespace std;
void TimetoString(time_t t, char s[32]);
time_t StringtoTime(char str[32]);
bool PayMoney(char start[32] ,char end[32],float &money,float &consum);

//ͳ�����ݺ���
void Querryonebill();
void QuerryAllbill();
void SpecialDate_Bill();
void Total_Money();
void Day_Money();
void Year_Money();
void LogoutCard();
void OneCard_Money();
void AllCard_Money();