#pragma once
#include"card.h"
#include"Bill.h"
#include"money.h"
#include<mysql.h>
#include<string>
#include<vector>
using namespace std;
class DButil
{
public:
	DButil();
	~DButil();
	bool OpenDB();
	bool CloseDB();
	bool IsExistCard(string cardname);
	bool CardMatch(string name, string password);
	bool AddCard(card one);
	bool QueryOne(string name, card &a);
	bool QueryMoney(string name);
	bool QueryOneBill(string name,vector<Bill> &b);
	bool QueryAllBill(vector<Bill> &ans);
	bool QueryAllCard(vector<card>& ans);
	bool QueryBill(string name, Bill &b);
	bool QueryBill_Done(string name, Bill &b);
	bool Up_Card(string name);
	bool AddBill(string name, float usemoney, float balance);
	bool UpdateBill(string name, float usemoney, float allmoney);
	bool Add_Money(string name,float addmoney);
	bool Refond_Card(string name, float refundmoney);
	bool Logout(string name);
	bool DeleteCard(string name);
	bool Delete_Bill(string name);
	bool Delete_RMBrecord(string name);
	bool QueryMoney_Record(vector<Money>& ans);
	bool Recovery(string name);
	bool Logout_CardStatistic(vector<card> &ans);
	void  Statistic_Allmoney(float &add, float &reduce);
public:
	string username;
	string password;
	string Host;
	string DataBase;
	int port;
	MYSQL connect;
	MYSQL_RES *result;
	MYSQL_ROW row;
	MYSQL_FIELD *fd;
	bool IsOpen;
	
};
