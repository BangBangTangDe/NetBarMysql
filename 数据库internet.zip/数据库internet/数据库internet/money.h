#pragma once
#include<string>
using namespace std;
class Money {
public:
	Money();
	~Money();
	void SetName(string name);
	void SetUpdateMoney(float money);
	void SetTime(string time);
	void SetReason(string reason);
	string GetName();
	string GetTime();
	string GetReason();
	float GetMoney();


private:
	string name;
	float updatemoney;
	string time;
	string reason;
};