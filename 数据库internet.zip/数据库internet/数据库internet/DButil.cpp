#include"stdafx.h"
#include"DButil.h"
#include"Tool.h"
#include"money.h"
#include<iostream>
#include<mysql.h>
#include<string>
#include<time.h>
using namespace std;
DButil::DButil()
{
	username = "root";
	password = "root";
	Host = "127.0.0.1";
	port = 3306;
	DataBase = "internetbar";
	IsOpen = false;
}
DButil::~DButil()
{
}
bool DButil::OpenDB()
{
	mysql_init(&connect);
	if (mysql_real_connect(&connect, Host.c_str(), username.c_str(), password.c_str(), DataBase.c_str(), port, NULL, 0))
	{
		IsOpen = true;
		return true;
	}
	else
	{
		return false;
	}
}
bool DButil::CloseDB()
{
	mysql_close(&connect);
	return true;
}
bool DButil:: IsExistCard(string cardname) 
{
	if (IsOpen) 
	{
		int res;
		string sql = "select * from card where cardid ='" + cardname + "'";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count > 0)
			{
				mysql_free_result(mysql_store_result(&connect));
				return true;
			}
		}
	}
	return false;
}
bool DButil::CardMatch(string name, string password)
{
	if (IsOpen)
	{
		int res;
		string sql = "select * from card where cardid ='" + name + "' and pwd ='"+password+"'";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count > 0)
			{	
				mysql_free_result(mysql_store_result(&connect));
				return true;
			
			}
		}
	}
	return false;
}
bool  DButil::AddCard(card one)
{
	if (IsOpen)
	{
		string sql;
		string sql1;
		char  status[10];
		char  usemoney[20];
		char  money[20];
		char  usecount[15];
		sprintf(status, "%d", one.GetStatus());
		sprintf(money, "%.2f", one.GetBalance());
		sprintf(usemoney, "%.2f", one.GetTotaluse());
		sprintf(usecount, "%d", one.GetUsecount());


		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		sql="insert into card values('" + one.GetName() + "', '" + one.GetPwd() + "', " + status + ", " + money + ", " + usemoney + ", " + usecount + ", '" + one.GetLast()+ "')";
		mysql_query(&connect, sql.c_str());
		mysql_free_result(mysql_store_result(&connect));
		sql1= "insert into money values('" + one.GetName() + "', " + money + ", '" + one.GetLast() + "','��ֵ')";
		mysql_query(&connect, sql1.c_str());
		mysql_free_result(mysql_store_result(&connect));
		return true;
	}
	else
	{
		cout << "connect failed!" << endl;
	}
	return false;
}
bool DButil::QueryOne(string name,card &a)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from card where cardid = '" + name + "'";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count == 0)
			{
				mysql_free_result(mysql_store_result(&connect));
				return false;
			}
			
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					a.setName(row[0]);
					a.setPassword(row[1]);
					a.setStatus(atoi(row[2]));
					a.setBalance(atof(row[3]));
					a.setTotaluse(atof(row[4]));
					a.setUsecount(atoi(row[5]));
					a.setLast(row[6]);
				}
			}
			if (result != NULL)
				mysql_free_result(result);
			return true;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}
	return false;
}
bool DButil::QueryMoney(string name) {
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from money where cardid = '" + name + "'";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->current_row > 0)
				return true;
			else
				return false;
		}
	}
}
bool DButil::QueryOneBill(string name,vector<Bill> &ans)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from bill where cardid ='"+name+"'";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count == 0)
			{
				mysql_free_result(result);
				return false;
			}
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					Bill *a;
					a = new Bill;
					a->SetName(row[0]);
					a->SetStart(row[1]);
					a->SetEnd(row[2]);
					a->SetBalance(atof(row[3]));
					a->SetUsemoney(atof(row[4]));
					ans.push_back(*a);
				}
			}
			if (result != NULL)
				mysql_free_result(result);

			return true;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}
	
}
bool DButil::QueryAllBill(vector<Bill> &ans)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from bill where end is not null";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count == 0)
			{
				mysql_free_result(result);
				return false;
			}
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					Bill *a;
					a = new Bill;
					a->SetName(row[0]);
					a->SetStart(row[1]);
					a->SetEnd(row[2]);
					a->SetBalance(atof(row[3]));
					a->SetUsemoney(atof(row[4]));
					ans.push_back(*a);
				}
			}
			if (result != NULL)
				mysql_free_result(result);

			return true;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}
}
bool DButil::QueryAllCard(vector<card> &ans)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from card ";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if(!res)
		{
			result = mysql_store_result(&connect);
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					card *a;
					a = new card;
					a->setName(row[0]);
					a->setPassword(row[1]);
					a->setStatus(atoi(row[2]));
					a->setBalance(atof(row[3]));
					a->setTotaluse(atof(row[4]));
					a->setUsecount(atoi(row[5]));
					a->setLast(row[6]);

					ans.push_back(*a);
				}
			}
			if (result != NULL)
				mysql_free_result(result);

			return true;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}
}
bool DButil::QueryBill(string name, Bill & b)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from bill where cardid = '" + name + "' and end is null	 ";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count == 0)return false;
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					b.SetName(row[0]);
					b.SetStart(row[1]);
					b.SetBalance(atof(row[3]));
					b.SetUsemoney(atof(row[4]));
				}
			}
			if (result != NULL)
			{
				mysql_free_result(result);
			}
				
			return true;
		}
		else {
			return false;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}
	return false;
}
bool DButil::QueryBill_Done(string name, Bill &b)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from bill where cardid = '" + name + "' and end is not null	 ";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					b.SetName(row[0]);
					b.SetStart(row[1]);
					b.SetBalance(atof(row[3]));
					b.SetUsemoney(atof(row[4]));
				}
			}
			if (result != NULL)
			{
				mysql_free_result(result);
			}

			return true;
		}
		else {
			return false;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}
	return false;

}
bool DButil::Up_Card(string name) 
{
	string sql = "update card set status =6 where cardid ='" + name + "'";
	mysql_query(&connect, "SET NAMES GBK");
	mysql_free_result(mysql_store_result(&connect));
	int res = mysql_query(&connect, sql.c_str());
	if (!res)
		return true;
	else
		return false;
}
bool DButil::AddBill(string name,float usemoney,float balance) {

	string sql;
	char times[32];
	time_t t = time(NULL);
	TimetoString(t, times);
	char bal[32];
	char use[32];
	sprintf(bal, "%f", balance);
	sprintf(use, "%f", usemoney);
	if (IsOpen) {
		sql = "insert into bill values('" + name + "','" + times + "'," + "NULL" + ",'" + bal + "','" + use + "')";
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		int res = mysql_query(&connect, sql.c_str());
		if (!res)return true;
		else
			return false;
	}
	return false;
}
bool DButil::UpdateBill(string name,float usemoney,float allmoney)
{
	if (IsOpen)
	{
		string sql="";
		string sql1 = "";
		char times[32];
		char money[32];
		char use[32];
		time_t now = time(NULL);
		TimetoString(now, times);
		string mytime = times;
		sprintf(money, "%f", allmoney);
		sprintf(use, "%f", usemoney);
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		sql ="update bill set end ='"+mytime+"',money="+money+",use_money="+use+   "where cardid='"  +name+  "'and end is null";
		sql1 = "update card set usecount =usecount+1,last_time='" + mytime + "',usemoney=usemoney+" + use + ",money=" + money +",status= 7 " +"where cardid='" + name + "'";
		int res=mysql_query(&connect, sql.c_str());
		int res1 = mysql_query(&connect, sql1.c_str());
		
		if ((!res) && (!res1))
			return true;
		else
			return false;
	}
}
bool DButil::Add_Money(string name, float addmoney) {
	if (IsOpen)
	{
		string sql;
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		char add[32];
		sprintf(add, "%f", addmoney);
		string add1 = add;
		sql = "update card set money = " + add1 +"+ money"+ " where cardid = '" + name + "'";
		int res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			return true;
		}
		return false;

	}
	return false;

}
bool DButil::Refond_Card(string name, float refundmoney)
{
	if (IsOpen)
	{
		string sql;
		string sql1;
		char now[32];
		time_t t;
		t = time(NULL);
		TimetoString(t, now);
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		char refund[32];
		sprintf(refund, "%f", refundmoney);
		string refund1 = refund;
		sql = "update card set money = money- " + refund1 + " where cardid = '" + name + "'";

		sql1 = "insert into money values('" + name + "', " + refund + ", '" + now + "','�˷�')";
		int res = mysql_query(&connect, sql.c_str());
		mysql_free_result(mysql_store_result(&connect));
		mysql_query(&connect, sql1.c_str());
		mysql_free_result(mysql_store_result(&connect));
		if (!res)
		{
			return true;
		}
		return false;

	}
	return false;

}
bool DButil::Logout_CardStatistic(vector<card> &ans)
{
	string sql;
	if (IsOpen)
	{
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		sql = "select * from card where status = 8";
		mysql_query(&connect, sql.c_str());
		result = mysql_store_result(&connect);
		if (result)
		{
			if (result->row_count == 0)
				return false;
			while (row = mysql_fetch_row(result))
			{
				card *a = new card;
				a->setName(row[0]);
				a->setPassword(row[1]);
				a->setStatus(atoi(row[2]));
				a->setBalance(atof(row[3]));
				a->setTotaluse(atof(row[4]));
				a->setUsecount(atoi(row[5]));
				a->setLast(row[6]);
				ans.push_back(*a);
				delete a;
			}
			return true;
		}
	}
}
bool DButil::Logout(string name)
{
	if (IsOpen)
	{
		string sql;
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		sql = "update card set status =8   where cardid = '" + name + "'";
		int res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			return true;
			mysql_free_result(mysql_store_result(&connect));
		}
		return false;

	}
	return false;
}
bool DButil::Recovery(string name)
{
	if (IsOpen)
	{
		string sql;
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		sql = "update card set status =7   where cardid = '" + name + "'";
		int res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			return true;
			mysql_free_result(mysql_store_result(&connect));
		}
		return false;

	}
	return false;
}
void DButil::Statistic_Allmoney(float &add, float &reduce)
{
	add=0;
	reduce = 0;
	string sql1;
	string sql2;
	int res; 
	MYSQL_ROW row1;
	MYSQL_ROW row2;
	if (IsOpen)
	{
		string a = "��ֵ";
		string b = "�˷�";
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		sql1 = "select * from money where reason='"+a+"'";
		sql2 = "select * from money where reason='"+b+"'";
		mysql_query(&connect, sql1.c_str());
		result = mysql_store_result(&connect);
		if (result)
		{
			while (row = mysql_fetch_row(result))
			{
				add += atof(row[1]);
			}
		}
		mysql_free_result(result);
		mysql_query(&connect, sql2.c_str());
		result = mysql_store_result(&connect);
		if (result)
		{
			while (row1 = mysql_fetch_row(result))
			{
				reduce += atof(row1[1]);
			}
		}
		mysql_free_result(result);
	}

}
bool DButil::DeleteCard(string name)
{
	if (IsOpen)
	{
		string sql;
		mysql_query(&connect, "set names gbk");
		mysql_free_result(mysql_store_result(&connect));
		sql = "delete from  card  where cardid = '" + name + "'";
		int res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			return true;
			mysql_free_result(mysql_store_result(&connect));
		}
		return false;

	}
	return false;
}
bool DButil::Delete_Bill(string name)
{
	string sql;
	int res;
	if (IsOpen)
	{
		if(name!="all")
		sql = "delete from bill where cardid = '" + name + "' and end is not null";
		else
		{
			sql = "delete from bill where end is not null";
		}
		mysql_query(&connect, sql.c_str());
		mysql_free_result(mysql_store_result(&connect));
		return true;
	}
	return false;
}
bool DButil::Delete_RMBrecord(string name)
{
	string sql;
	int res;
	if (IsOpen)
	{
		if (name != "all")
			sql = "delete from money where cardid = '" + name;
		else
		{
			sql = "delete from money";
		}
		mysql_query(&connect, sql.c_str());
		mysql_free_result(mysql_store_result(&connect));
		return true;
	}
	return false;

}
bool DButil::QueryMoney_Record(vector<Money> &ans)
{
	string sql;
	int res;
	if (IsOpen)
	{
		sql = "select * from money";
		mysql_query(&connect, "SET NAMES GBK");
		mysql_free_result(mysql_store_result(&connect));
		res = mysql_query(&connect, sql.c_str());
		if (!res)
		{
			result = mysql_store_result(&connect);
			if (result->row_count == 0)
			{
				mysql_free_result(result);
				return false;
			}
			if (result)
			{
				while (row = mysql_fetch_row(result))
				{
					Money *a;
					a = new Money;
					a->SetName(row[0]);
					a->SetUpdateMoney(atof(row[1]));
					a->SetTime(row[2]);
					a->SetReason(row[3]);
					ans.push_back(*a);
				}
			}
			if (result != NULL)
				mysql_free_result(result);

			return true;
		}
	}
	else
	{
		cout << "query failed!" << endl;
		return false;
	}

}

