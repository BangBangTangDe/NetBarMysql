#include"stdafx.h"
#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include"global.h"
#include<iostream>
#include<vector>
#include "Tool.h"
#include"money.h"
#include"Bill.h"
#include"DButil.h"
using namespace std;

void TimetoString(time_t t, char s[32])
{
	struct tm *time;
	time = localtime(&t);
	strftime(s, 128, "%F %T", time);
}
time_t StringtoTime(char str[32]) {

	struct tm tm1;
	time_t time1 = NULL;

	sscanf(str, "%4d-%2d-%2d %2d:%2d:%2d",
		&tm1.tm_year,
		&tm1.tm_mon,
		&tm1.tm_mday,
		&tm1.tm_hour,
		&tm1.tm_min,
		&tm1.tm_sec);
	tm1.tm_year -= 1900;
	tm1.tm_mon--;
	tm1.tm_isdst = -1;
	time1 = mktime(&tm1);
	return time1;
}
bool PayMoney(char start[32], char  end[32], float &money,float &consum) {
	time_t t1, t2;
	t1 = StringtoTime(start);
	t2 = StringtoTime(end);
	float second = t2 - t1;
	float min = second * 1.0 / 60;
	if (min <= 30)
	{
		consum = MIN_CONSUME;
	}
	else
	{
		min = min * 1.0 / 30 + 1;
		consum = min * Single;
	}

	if (money >= consum)
	{
		money -= consum;
		return true;
	}
	else
	{
		return false;
	}
}
void Querryonebill()
{
	string name;
	vector<Bill> b;
	DButil db;
	db.OpenDB();
	cout << "���뿨�ţ�";
	cin >> name;
	if (db.QueryOneBill(name,b))
	{
		cout << "---------------------�������Ѽ�¼-------------------" << endl;
		cout << "����\t�ϻ�ʱ��\t\t�»�ʱ��\t\t���\t�ۼ�ʹ�ý��" << endl;
		for (int i = 0; i < b.size(); i++)
		{
			cout << b[i].GetName() << "\t" << b[i].GetStart() << "\t" << b[i].GetEnd() << "\t" << b[i].GetBalance() << "\t" << b[i].GetUsemoney() << endl;
		}
	}
	else
	{
		cout << "�˿������Ѽ�¼������!" << endl;
	}

}
void QuerryAllbill()
{
	vector<Bill> all;
	DButil db;
	db.OpenDB();
	if (db.QueryAllBill(all))
	{
		cout << "---------------------�������Ѽ�¼-------------------" << endl;
		cout << "����\t�ϻ�ʱ��\t\t�»�ʱ��\t\t���\t�ۼ�ʹ�ý��" << endl;
		for (int i = 0; i < all.size(); i++)
		{
			cout << all[i].GetName() << "\t" << all[i].GetStart() << "\t" << all[i].GetEnd() << "\t" << all[i].GetBalance() << "\t" << all[i].GetUsemoney() << endl;
		}
	}
	else
	{
		cout << "��¼Ϊ�գ�" << endl;
	}
}
void SpecialDate_Bill()
{
	int year1, month1, day1;
	int year2, month2, day2;
	DButil mydb;
	vector<Bill> mybill;
	mydb.OpenDB();
	cout << "�������ѯ���Ѽ�¼��ʱ��Σ�" << endl;
	cout << "��ѯ��ʼ���ڣ�" << endl;
	cout << "��--->"; cin >> year1;   cout << "��--->"; cin >> month1;  cout << "��--->"; cin >> day1; cout << endl;
	cout << "��ѯ�������ڣ�" << endl;
	cout << "��--->"; cin >> year2;  cout << "��--->"; cin >> month2; cout << "��--->"; cin >> day2; cout << endl;
	struct tm t1, t2;
	time_t begin;
	time_t end;
	t1.tm_year = year1 - 1900;
	t1.tm_mon = month1 - 1;
	t1.tm_mday = day1;
	t1.tm_hour = 0;
	t1.tm_isdst = -1;
	t1.tm_min = 0;
	t1.tm_yday = 0;
	t1.tm_sec = 0;

	t2.tm_year = year2 - 1900;
	t2.tm_mon = month2 - 1;
	t2.tm_mday = day2;

	t2.tm_hour = 0;
	t2.tm_isdst = -1;
	t2.tm_min = 0;
	t2.tm_yday = 0;
	t2.tm_sec = 0;
	begin = mktime(&t1);
	end = mktime(&t2);
	if (begin > end)
	{
		cout << "���ڸ�ʽ����" << endl;
		return;
	}
	else
	{
		mydb.QueryAllBill(mybill);
		if (mybill.empty())
		{
			cout << "��¼Ϊ�գ�" << endl;
			return;
		}
		else
		{
			cout << "---------------------�������Ѽ�¼-------------------" << endl;
			cout << "����\t�ϻ�ʱ��\t\t�»�ʱ��\t\t���\t�ۼ�ʹ�ý��" << endl;
			cout << endl;
			for (int i = 0; i < mybill.size(); i++)
			{
				string str = mybill[i].GetStart();
				string str1 = mybill[i].GetEnd();
				char * tmp = new char[str.length()];
				char * tmp1 = new char[str.length()];
				str.copy(tmp, str.length(), 0);
				time_t s = StringtoTime(tmp);
				time_t e = StringtoTime(tmp1);
				if (s >= begin && e <= end)
				{
					
					cout << mybill[i].GetName() << "\t" << mybill[i].GetStart() << "\t" << mybill[i].GetEnd() << "\t" << mybill[i].GetBalance() << "\t" << mybill[i].GetUsemoney() << endl;
				}
			}

		}
	}
}
void Total_Money()
{
	float add=0;
	float reduce = 0;
	DButil db;
	db.OpenDB();
	db.Statistic_Allmoney(add, reduce);

	float real= add - reduce;
	if (real == 0)
	{
		cout << "����Ϊ0" << endl;
		return;
	}
	else
	{
		cout << "-----------Ӫҵ�ܶ�----------" << endl;
		cout << "\t\t�ܽ��=" << real<<"Ԫ" << endl;
	}
}
void Day_Money() {
	int year1=0, month1=0, day1=0;
	time_t t2;
	time_t begin;
	time_t end;
	float money = 0;
	vector<Bill> mybill;
	DButil mydb;
	mydb.OpenDB();

	cout << "�������ѯ������(��ʽ:2020-1-18)��" << endl;
	scanf("%d-%d-%d", &year1, &month1, &day1);
	struct tm t1;
	t1.tm_year = year1 - 1900;
	t1.tm_mon = month1 - 1;
	t1.tm_mday = day1;
	t1.tm_hour = 0;
	t1.tm_isdst = 0;
	t1.tm_min = 0;
	t1.tm_yday = 0;
	t1.tm_sec = 0;


	begin = mktime(&t1);
	end = time(NULL);
	mydb.QueryAllBill(mybill);
	for (int i = 0; i < mybill.size(); i++)
	{
		string str = mybill[i].GetStart();
		string str1 = mybill[i].GetEnd();
		char * tmp = new char[str.length()];
		char * tmp1 = new char[str1.length()];
		str.copy(tmp, str.length(), 0);
		str.copy(tmp1, str1.length(), 0);
		time_t s = StringtoTime(tmp);
		time_t e = StringtoTime(tmp1);
		if (s >= begin && e <= end)
		{
			money += mybill[i].GetUsemoney();
		}

	}
	cout << "-------------------��Ӫҵ��ͳ��--------------------" << endl;
	if (money == 0)
	{
		cout << "\t\t�ռ�¼" << endl;
	}
	else
	{
		cout << "\t\t��Ӫҵ��=" << money << endl;
	}

}
void Year_Money() {
	DButil mydb;
	mydb.OpenDB();
	vector<Bill> mybill;
	int year1, month1, day1;
	float money = 0;
	month1 = 1; day1 = 1;
	time_t begin;
	time_t end;
	struct tm t1;
	struct tm t2;
	cout << "������ݣ�" << endl;
	cin >> year1;

	t1.tm_year = year1 - 1900;
	t1.tm_mon = month1 - 1;
	t1.tm_mday = day1;
	t1.tm_hour = 0;
	t1.tm_isdst = 0;
	t1.tm_min = 0;
	t1.tm_yday = 0;
	t1.tm_sec = 0;

	t2.tm_year = year1+1 - 1900;
	t2.tm_mon = month1 - 1;
	t2.tm_mday = day1;

	t2.tm_hour = 0;
	t2.tm_isdst = -1;
	t2.tm_min = 0;
	t2.tm_yday = 0;
	t2.tm_sec = 0;

	begin = mktime(&t1);
	end = mktime(&t2);
	mydb.QueryAllBill(mybill);
	for (int i = 0; i < mybill.size(); i++)
	{
		string str = mybill[i].GetStart();
		string str1 = mybill[i].GetEnd();
		char * tmp = new char[str.length()];
		char * tmp1 = new char[str.length()];
		str.copy(tmp, str.length(), 0);
		time_t s = StringtoTime(tmp);
		time_t e = StringtoTime(tmp1);
		if (s >= begin && e <= end)
		{
			money += mybill[i].GetUsemoney();
		}

	}
	cout << "-------------------"<<year1<<"��Ӫҵ��ͳ��--------------------" << endl;
	if (money == 0)
	{
		cout << "\t\t�ռ�¼" << endl;
	}
	else
	{
		cout << "\t\t<"<<year1<<"��Ӫҵ��=" << money << endl;
	}

}
void LogoutCard() {
	cout << "--------------------ע��������Ϣͳ��--------------------" << endl;
	cout << endl;
	DButil db;
	db.OpenDB();
	vector<card> ans;
	if (!db.Logout_CardStatistic(ans))
		cout << "---------��¼Ϊ��-------" << endl;
	else
	{
		cout << "����\t�ۼ�ʹ�ý��\t�ϴ�ʹ��\n" << endl;
		for (int i = 0; i < ans.size(); i++)
		{
			cout << ans[i].GetName() << "\t" << ans[i].GetTotaluse() << "\t" << ans[i].GetLast() << endl;

		}
		cout << "\t  ע����������:" << ans.size() << endl;
	}
}
void OneCard_Money()
{
	string name;
	vector<Money> my;
	DButil mydb;
	mydb.OpenDB();
	cout << "�����ѯ�Ŀ���:" << endl;
	cin >> name;
	cout << "---------������ֵ�˷Ѽ�¼--------------" << endl;
	if (!mydb.QueryMoney_Record(my))
		cout << "\t��¼Ϊ�գ�" << endl;
	else
	{
		
		cout << "����\t����\tʱ��\t\t\t����˵��" << endl;
		cout << endl;
		for (int i = 0; i < my.size(); i++)
		{
			if (my[i].GetName() == name)
			{
				cout << my[i].GetName() << "\t" << my[i].GetMoney() << "\t" << my[i].GetTime() << "\t" << my[i].GetReason() << endl;
			}
		}
	}
}
void AllCard_Money() {
	vector<Money> my;
	DButil mydb;
	mydb.OpenDB();
	cout << "---------���п���ֵ�˷Ѽ�¼--------------" << endl;
	if (!mydb.QueryMoney_Record(my))
		cout << "\t��¼Ϊ�գ�" << endl;
	else
	{
		
		cout << "����\t����\tʱ��\t\t\t����˵��" << endl;
		for (int i = 0; i < my.size(); i++)
		{
			cout << my[i].GetName() << "\t" << my[i].GetMoney() << "\t" << my[i].GetTime() << "\t" << my[i].GetReason() << endl;
		}
	}
}
