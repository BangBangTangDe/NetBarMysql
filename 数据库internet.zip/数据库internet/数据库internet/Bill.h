#pragma once
#include<string>
using  namespace std;
class Bill{
public:
	Bill();
	~Bill();
	string GetName();
	string GetStart();
	string GetEnd();
	float GetBalance();
	float GetUsemoney();
	void SetName(string name);
	void SetBalance(float balance);
	void SetUsemoney(float usemoney);
	void SetStart(string start);
	void SetEnd(string end);



private:
	string name;
	float balance;
	float use_money;
	string start;
	string end;
};