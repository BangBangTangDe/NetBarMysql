#include"stdafx.h"
#include"card.h"
#include"global.h"
card::card() {}
card::card(string name, string password, float balance,string time) {
	Name = name;
	Pwd = password;
	Last = time;
	Start = time;
	Balance = balance;
	UseCount = 0;
	TotalUse = 0;
	Status = UNUSE;
}
card::~card()
{

}
void card::setName(string name) {
	Name = name;
}
void card::setPassword(string password) {
	Pwd = password;
}
void card::setStatus(int ans) {
	Status = ans;
}
void card::setStart(string start) {
	Start = start;
}
void card::setLast(string last) {
	Last = last;
}
void card::setTotaluse(float total) {
	TotalUse = total;
}
void card :: setUsecount(int n)
{
	UseCount = n;
}
void card::setBalance(float money)
{
	Balance = money;
}
string card::GetName()
{
	return Name;
}
string card:: GetPwd()
{
	return Pwd;
}
int  card::GetStatus() {

	return Status;
}
string card::GetStart() {
	return Start;
}
string card::GetLast()
{
	return Last;
}
float card::GetTotaluse()
{
	return TotalUse;
}
int card::GetUsecount()
{
	return UseCount;
}
float card::GetBalance()
{
	return Balance;
}