#pragma once
#include"DButil.h"
class Manager {
public:
	DButil mydb;
	Manager();
	~Manager();
	void Draw();
	void open_menu();
	bool AddCard();
	bool Query();
	bool Up_Computer();
	bool Down_Computer();
	bool AddMoney();
	bool Refund();
	bool Logout_Card();
	bool Delete_Card();
	bool Recovery_Card();
	bool Delete_BillRecord();
	bool Delete_MoneyRecord();
	bool Data_Statistics();

};
