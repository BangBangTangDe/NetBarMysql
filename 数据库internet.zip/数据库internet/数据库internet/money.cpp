#include"stdafx.h"
#include "money.h"

Money::Money()
{
}
Money::~Money()
{
}
void Money::SetName(string name)
{
	this->name = name;
}
void Money::SetUpdateMoney(float money)
{
	this->updatemoney = money;
}
void Money::SetTime(string time)
{
	this->time = time;
}
void Money::SetReason(string reason)
{
	this->reason = reason;
}
string Money::GetName()
{
	return name;
}
string Money::GetTime()
{
	return time;
}
string Money::GetReason()
{
	return reason;
}
float Money::GetMoney()
{
	return updatemoney;
}
