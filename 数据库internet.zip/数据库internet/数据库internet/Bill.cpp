#include"stdafx.h"
#include"Bill.h"
#include<string>

Bill::Bill() {}
Bill::~Bill(){}
string Bill::GetName() {
	return  name;
}
string Bill::GetStart() {
	return start;
}
string Bill::GetEnd() {
	return end;
}
float Bill::GetBalance() {
	return balance;
}
float Bill::GetUsemoney() {
	return use_money;
}
void Bill::SetName(string name) {
	this->name = name;
}
void Bill::SetBalance(float balance) {
	this->balance = balance;
}
void  Bill::SetUsemoney(float usemoney) {
	this->use_money = usemoney;
}
void  Bill::SetStart(string start) {
	this->start = start;
}
void Bill::SetEnd(string end) {
	this->end = end;
}